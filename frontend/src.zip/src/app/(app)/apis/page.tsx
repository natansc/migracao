"use client";

/* eslint-disable react-hooks/set-state-in-effect */
import { useCallback, useEffect, useMemo, useState } from "react";

const API_BASE_URL =
  process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:3001";

type ApiItem = {
  id: number;
  name: string;
  description: string;
  host: string;
  username: string;
  createdAt: string;
  updatedAt: string;
  lastModifiedBy: string;
};

type FormState = {
  name: string;
  description: string;
  host: string;
  username: string;
  password: string;
  token: string;
};

const emptyForm: FormState = {
  name: "",
  description: "",
  host: "",
  username: "",
  password: "",
  token: "",
};

const inputClass =
  "mt-1.5 w-full rounded-lg border border-[#E2E4E7] bg-[#FFFFFF] px-3.5 py-2.5 text-sm text-[#191A1C] placeholder:text-[#9A9B9E] transition focus:border-[#1A6EE8] focus:outline-none focus:ring-2 focus:ring-[#1A6EE8]/20";

const fields: { key: keyof FormState; label: string; placeholder: string }[] = [
  { key: "name", label: "Nome", placeholder: "" },
  { key: "description", label: "Descrição", placeholder: "" },
  { key: "host", label: "Host", placeholder: "https://api.exemplo.com" },
  { key: "username", label: "Usuário", placeholder: "" },
  { key: "password", label: "Senha", placeholder: "" },
  { key: "token", label: "Token", placeholder: "" },
];

function authHeaders(): Record<string, string> {
  const token = window.localStorage.getItem("tm_access_token");
  return token ? { Authorization: `Bearer ${token}` } : {};
}

export default function ApisPage() {
  const [items, setItems] = useState<ApiItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/api-list`, {
        headers: authHeaders(),
      });
      if (!response.ok) throw new Error();
      setItems((await response.json()) as ApiItem[]);
      setError(null);
    } catch {
      setError("Não foi possível carregar as APIs cadastradas.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    if (!term) return items;
    return items.filter((item) =>
      [item.name, item.description, item.host, item.username]
        .join(" ")
        .toLowerCase()
        .includes(term),
    );
  }, [items, search]);

  function openCreate() {
    setEditingId(null);
    setForm(emptyForm);
    setFormError(null);
    setDrawerOpen(true);
  }

  function openEdit(item: ApiItem) {
    setEditingId(item.id);
    setForm({
      name: item.name,
      description: item.description,
      host: item.host,
      username: item.username,
      password: "",
      token: "",
    });
    setFormError(null);
    setDrawerOpen(true);
  }

  function closeDrawer() {
    if (saving) return;
    setDrawerOpen(false);
  }

  function setField(key: keyof FormState, value: string) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSaving(true);
    setFormError(null);
    try {
      const isEdit = editingId !== null;
      const payload: Record<string, string> = {
        name: form.name,
        description: form.description,
        host: form.host,
        username: form.username,
        lastModifiedBy: window.localStorage.getItem("tm_username") ?? "",
      };
      if (!isEdit || form.password) payload.password = form.password;
      if (!isEdit || form.token) payload.token = form.token;

      const response = await fetch(
        isEdit
          ? `${API_BASE_URL}/api/api-update/${editingId}`
          : `${API_BASE_URL}/api/api-create`,
        {
          method: isEdit ? "PUT" : "POST",
          headers: { "Content-Type": "application/json", ...authHeaders() },
          body: JSON.stringify(payload),
        },
      );
      if (!response.ok) throw new Error();

      setDrawerOpen(false);
      await load();
    } catch {
      setFormError("Não foi possível salvar a API. Tente novamente.");
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(item: ApiItem) {
    if (!window.confirm(`Deseja realmente excluir a API "${item.name}"?`)) return;
    setError(null);
    try {
      const response = await fetch(
        `${API_BASE_URL}/api/api-delete/${item.id}`,
        { method: "DELETE", headers: authHeaders() },
      );
      if (!response.ok) throw new Error();
      await load();
    } catch {
      setError("Não foi possível excluir a API.");
    }
  }

  const isEdit = editingId !== null;

  return (
    <section>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-heading text-2xl font-bold text-[#191A1C]">APIs</h1>
          <p className="mt-1 text-sm text-[#5C5E61]">
            Cadastro e manutenção das integrações de API.
          </p>
        </div>
        <button
          type="button"
          onClick={openCreate}
          className="rounded-lg bg-[#1A6EE8] px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-[#1656C0]"
        >
          + Nova API
        </button>
      </div>

      <div className="mt-6">
        <input
          type="search"
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          placeholder="Buscar por nome, descrição, host ou usuário..."
          className="w-full max-w-md rounded-lg border border-[#E2E4E7] bg-[#FFFFFF] px-3.5 py-2.5 text-sm text-[#191A1C] placeholder:text-[#9A9B9E] focus:border-[#1A6EE8] focus:outline-none focus:ring-2 focus:ring-[#1A6EE8]/20"
        />
      </div>

      {error && (
        <div
          role="alert"
          className="mt-4 rounded-lg border border-[#E53E3E]/30 bg-[#E53E3E]/10 px-3.5 py-2.5 text-sm text-[#E53E3E]"
        >
          {error}
        </div>
      )}

      <div className="mt-4 overflow-x-auto rounded-xl border border-[#E2E4E7]">
        <table className="min-w-full text-sm">
          <thead className="bg-[#F5F5F5] text-left text-[#5C5E61]">
            <tr>
              <th className="px-4 py-3 font-medium">Nome</th>
              <th className="px-4 py-3 font-medium">Host</th>
              <th className="px-4 py-3 font-medium">Usuário</th>
              <th className="px-4 py-3 font-medium">Última alteração</th>
              <th className="px-4 py-3 text-right font-medium">Ações</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-[#5C5E61]">
                  Carregando...
                </td>
              </tr>
            ) : filtered.length === 0 ? (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-[#5C5E61]">
                  Nenhuma API encontrada.
                </td>
              </tr>
            ) : (
              filtered.map((item) => (
                <tr key={item.id} className="border-t border-[#E2E4E7]">
                  <td className="px-4 py-3">
                    <p className="font-medium text-[#191A1C]">{item.name}</p>
                    <p className="text-xs text-[#9A9B9E]">{item.description}</p>
                  </td>
                  <td className="px-4 py-3 text-[#9A9B9E]">{item.host}</td>
                  <td className="px-4 py-3 text-[#9A9B9E]">{item.username}</td>
                  <td className="px-4 py-3 text-[#9A9B9E]">
                    <p>{item.lastModifiedBy}</p>
                    <p className="text-xs text-[#9A9B9E]">
                      {new Date(item.updatedAt).toLocaleString("pt-BR")}
                    </p>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex justify-end gap-3">
                      <button
                        type="button"
                        onClick={() => openEdit(item)}
                        className="text-sm font-medium text-[#1A6EE8] hover:underline"
                      >
                        Editar
                      </button>
                      <button
                        type="button"
                        onClick={() => void handleDelete(item)}
                        className="text-sm font-medium text-[#E53E3E] hover:underline"
                      >
                        Excluir
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {drawerOpen && (
        <div className="fixed inset-0 z-40 flex justify-end">
          <div
            className="absolute inset-0 bg-[#191A1C]/40"
            onClick={closeDrawer}
            aria-hidden="true"
          />
          <form
            onSubmit={handleSubmit}
            className="relative z-50 flex h-full w-full max-w-md flex-col bg-[#FFFFFF] shadow-xl"
          >
            <div className="flex items-center justify-between border-b border-[#E2E4E7] px-6 py-5">
              <h2 className="font-heading text-lg font-semibold text-[#191A1C]">
                {isEdit ? "Editar API" : "Nova API"}
              </h2>
              <button
                type="button"
                onClick={closeDrawer}
                aria-label="Fechar"
                className="rounded-md p-1.5 text-[#9A9B9E] transition hover:bg-[#F0F4F8] hover:text-[#191A1C]"
              >
                ✕
              </button>
            </div>

            <div className="flex-1 space-y-4 overflow-y-auto px-6 py-5">
              {fields.map((field) => {
                const secret = field.key === "password" || field.key === "token";
                return (
                  <div key={field.key}>
                    <label
                      htmlFor={`api-${field.key}`}
                      className="block text-sm font-medium text-[#191A1C]"
                    >
                      {field.label}
                    </label>
                    <input
                      id={`api-${field.key}`}
                      type={secret ? "password" : "text"}
                      required={secret ? !isEdit : true}
                      value={form[field.key]}
                      onChange={(e) => setField(field.key, e.target.value)}
                      placeholder={
                        secret && isEdit
                          ? "Deixe em branco para manter"
                          : field.placeholder
                      }
                      className={inputClass}
                    />
                  </div>
                );
              })}

              {formError && (
                <div
                  role="alert"
                  className="rounded-lg border border-[#E53E3E]/30 bg-[#E53E3E]/10 px-3.5 py-2.5 text-sm text-[#E53E3E]"
                >
                  {formError}
                </div>
              )}
            </div>

            <div className="flex justify-end gap-2 border-t border-[#E2E4E7] px-6 py-4">
              <button
                type="button"
                onClick={closeDrawer}
                className="rounded-lg border border-[#E2E4E7] bg-[#FFFFFF] px-4 py-2.5 text-sm font-medium text-[#191A1C] transition hover:bg-[#F0F4F8]"
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={saving}
                className="rounded-lg bg-[#1A6EE8] px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-[#1656C0] disabled:cursor-not-allowed disabled:opacity-60"
              >
                {saving ? "Salvando..." : isEdit ? "Atualizar" : "Cadastrar"}
              </button>
            </div>
          </form>
        </div>
      )}
    </section>
  );
}
