"use client";

import { useEffect, useState, useSyncExternalStore } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";

type NavItem = { label: string; href: string; icon: React.ReactNode };

const iconClass = "h-5 w-5 shrink-0";

const HomeIcon = (
  <svg className={iconClass} fill="none" stroke="currentColor" strokeWidth={1.6} viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1v-9.5Z" />
  </svg>
);

const ApiIcon = (
  <svg className={iconClass} fill="none" stroke="currentColor" strokeWidth={1.6} viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" d="m8 9-4 3 4 3m8-6 4 3-4 3M14 5l-4 14" />
  </svg>
);

const sections: { title: string; items: NavItem[] }[] = [
  {
    title: "Geral",
    items: [{ label: "Home", href: "/dashboard", icon: HomeIcon }],
  },
  {
    title: "Administrativo",
    items: [{ label: "APIs", href: "/apis", icon: ApiIcon }],
  },
];

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const [collapsed, setCollapsed] = useState(false);
  const hydrated = useSyncExternalStore(
    () => () => {},
    () => true,
    () => false,
  );
  const token = hydrated
    ? window.localStorage.getItem("tm_access_token")
    : null;
  const username = hydrated
    ? (window.localStorage.getItem("tm_username") ?? "")
    : "";
  const ready = hydrated && !!token;

  useEffect(() => {
    if (hydrated && !token) {
      router.replace("/login");
    }
  }, [hydrated, token, router]);

  function handleLogout() {
    window.localStorage.removeItem("tm_access_token");
    window.localStorage.removeItem("tm_username");
    router.replace("/login");
  }

  if (!ready) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#F5F5F5]">
        <div className="glass rounded-2xl p-4 shadow-neon">
          <div className="flex items-center gap-2">
            <span className="flex h-8 w-8 rounded-lg bg-gradient-to-br from-[#1A6EE8] to-[#2E4CFF] flex items-center justify-center font-heading text-xs font-bold text-white">
              TM
            </span>
            <span className="font-heading text-sm font-semibold text-[#191A1C] tracking-wide uppercase">
              Trinus
            </span>
          </div>
          <p className="mt-2 text-xs text-[#5C5E61]">Carregando...</p>
        </div>
      </main>
    );
  }

  const initials = (username || "U").slice(0, 2).toUpperCase();

  return (
    <div className="flex min-h-screen bg-[#F5F5F5]">
      <aside
        className={`sticky top-0 flex h-screen shrink-0 flex-col border-r border-[#E2E4E7] bg-[#FFFFFF] transition-all ${
          collapsed ? "w-[72px]" : "w-64"
        }`}
      >
        <div className="flex items-center justify-between px-4 py-5">
          <div className="flex items-center gap-3 overflow-hidden">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-[#1A6EE8] font-heading text-sm font-bold text-white">
              TM
            </span>
            {!collapsed && (
              <span className="font-heading text-lg font-semibold text-[#191A1C]">
                Trinus
              </span>
            )}
          </div>
          <button
            type="button"
            onClick={() => setCollapsed((value) => !value)}
            aria-label="Recolher menu"
            className="rounded-md p-1.5 text-[#9A9B9E] transition hover:bg-[#F0F4F8] hover:text-[#191A1C]"
          >
            <svg className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={1.6} viewBox="0 0 24 24">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d={collapsed ? "m10 8 4 4-4 4M4 5h16v14H4z" : "m14 8-4 4 4 4M4 5h16v14H4z"}
              />
            </svg>
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 pb-4">
          {sections.map((section) => (
            <div key={section.title} className="mb-5">
              {!collapsed && (
                <p className="px-2 pb-2 text-sm text-[#9A9B9E]">{section.title}</p>
              )}
              <ul className="space-y-1">
                {section.items.map((item) => {
                  const active = pathname.startsWith(item.href);
                  return (
                    <li key={item.href}>
                      <Link
                        href={item.href}
                        title={item.label}
                        className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition ${
                          active
                            ? "bg-[#1A6EE8]/10 font-medium text-[#1656C0]"
                            : "text-[#191A1C] hover:bg-[#F0F4F8]"
                        } ${collapsed ? "justify-center" : ""}`}
                      >
                        {item.icon}
                        {!collapsed && <span>{item.label}</span>}
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </div>
          ))}
        </nav>

        <div className="border-t border-[#E2E4E7] p-3">
          <div className={`flex items-center gap-3 ${collapsed ? "justify-center" : ""}`}>
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#1A6EE8] text-xs font-semibold text-white">
              {initials}
            </span>
            {!collapsed && (
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-[#191A1C]">{username}</p>
                <button
                  type="button"
                  onClick={handleLogout}
                  className="text-xs text-[#9A9B9E] transition hover:text-[#E53E3E]"
                >
                  Sair
                </button>
              </div>
            )}
          </div>
        </div>
      </aside>

      <main className="min-w-0 flex-1 p-6">
        <div className="min-h-[calc(100vh-3rem)] rounded-3xl bg-[#FFFFFF] p-8 shadow-sm">
          {children}
        </div>
      </main>
    </div>
  );
}
