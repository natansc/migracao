export default function DashboardPage() {
  return (
    <section>
      <h1 className="font-heading text-2xl font-bold text-[#191A1C]">
        Painel de migração
      </h1>
      <p className="mt-2 text-sm text-[#5C5E61]">
        Bem-vindo. As telas gerenciais serão disponibilizadas em breve.
      </p>

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {[
          { title: "Jobs de migração", value: "—" },
          { title: "Registros migrados", value: "—" },
          { title: "Pendências", value: "—" },
        ].map((card) => (
          <div
            key={card.title}
            className="rounded-xl border border-[#E2E4E7] bg-[#FFFFFF] p-5 shadow-sm"
          >
            <p className="text-sm text-[#5C5E61]">{card.title}</p>
            <p className="mt-2 font-heading text-2xl font-bold text-[#191A1C]">
              {card.value}
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}
